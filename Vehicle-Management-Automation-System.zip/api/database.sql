-- Create database (Standard SQL does not support CREATE DATABASE, but we'll keep it for integration)
CREATE SCHEMA IF NOT EXISTS vehicle_management;
SET SCHEMA 'vehicle_management';

-- Create vehicles table
CREATE TABLE vehicles (
    id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    make VARCHAR(100) NOT NULL,
    model VARCHAR(100) NOT NULL,
    year INTEGER NOT NULL,
    license_plate VARCHAR(20) NOT NULL UNIQUE,
    type VARCHAR(50) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'Available',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CHECK (status IN ('Available', 'Rented', 'Maintenance'))
);

-- Create rental_types table
CREATE TABLE rental_types (
    id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    base_rate DECIMAL(10, 2) NOT NULL,
    duration VARCHAR(50) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create passengers table
CREATE TABLE passengers (
    id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    phone VARCHAR(20) NOT NULL,
    license_number VARCHAR(50) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create bookings table
CREATE TABLE bookings (
    id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    vehicle_id INTEGER NOT NULL,
    passenger_id INTEGER NOT NULL,
    rental_type_id INTEGER NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'Active',
    total_amount DECIMAL(10, 2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (vehicle_id) REFERENCES vehicles(id) ON DELETE CASCADE,
    FOREIGN KEY (passenger_id) REFERENCES passengers(id) ON DELETE CASCADE,
    FOREIGN KEY (rental_type_id) REFERENCES rental_types(id) ON DELETE CASCADE,
    CHECK (status IN ('Active', 'Completed', 'Cancelled'))
);

-- Create payments table
CREATE TABLE payments (
    id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    booking_id INTEGER NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    method VARCHAR(20) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'Pending',
    date DATE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE,
    CHECK (method IN ('Bank Transfer', 'Credit Card')),
    CHECK (status IN ('Pending', 'Completed', 'Failed'))
);

-- Insert sample data for vehicles
INSERT INTO vehicles (make, model, year, license_plate, type, status) VALUES
('Toyota', 'Camry', 2023, 'ABC-123', 'Sedan', 'Available'),
('Ford', 'Transit', 2022, 'XYZ-789', 'Van', 'Rented'),
('BMW', 'X5', 2024, 'LMN-456', 'SUV', 'Maintenance');

-- Insert sample data for rental_types
INSERT INTO rental_types (name, description, base_rate, duration) VALUES
('Daily Rental', 'Standard daily vehicle rental', 50.00, '24 hours'),
('Weekly Rental', 'Extended weekly rental package', 300.00, '7 days'),
('Monthly Rental', 'Long-term monthly rental', 1200.00, '30 days');

-- Insert sample data for passengers
INSERT INTO passengers (first_name, last_name, email, phone, license_number) VALUES
('John', 'Smith', 'john.smith@email.com', '+1-555-0123', 'DL123456789'),
('Sarah', 'Johnson', 'sarah.j@email.com', '+1-555-0456', 'DL987654321'),
('Michael', 'Brown', 'm.brown@email.com', '+1-555-0789', 'DL456789123');

-- Insert sample data for bookings
INSERT INTO bookings (vehicle_id, passenger_id, rental_type_id, start_date, end_date, status, total_amount) VALUES
(1, 1, 1, '2024-01-15', '2024-01-16', 'Active', 50.00),
(2, 2, 2, '2024-01-10', '2024-01-17', 'Completed', 300.00);

-- Insert sample data for payments
INSERT INTO payments (booking_id, amount, method, status, date) VALUES
(1, 50.00, 'Credit Card', 'Completed', '2024-01-15'),
(2, 300.00, 'Bank Transfer', 'Completed', '2024-01-10');
