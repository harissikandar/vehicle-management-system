<?php
require_once 'config.php';

$pdo = getConnection();
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        try {
            $stmt = $pdo->query("SELECT * FROM payments ORDER BY id DESC");
            $payments = $stmt->fetchAll();
            sendResponse($payments);
        } catch (PDOException $e) {
            sendResponse(['error' => 'Failed to fetch payments: ' . $e->getMessage()], 500);
        }
        break;

    case 'POST':
        try {
            $data = getRequestBody();
            
            // Validate payment method
            if (!in_array($data['method'], ['Bank Transfer', 'Credit Card'])) {
                sendResponse(['error' => 'Invalid payment method. Only Bank Transfer and Credit Card are allowed.'], 400);
                return;
            }
            
            $stmt = $pdo->prepare("
                INSERT INTO payments (booking_id, amount, method, status, date) 
                VALUES (?, ?, ?, ?, ?)
            ");
            
            $stmt->execute([
                $data['booking_id'],
                $data['amount'],
                $data['method'],
                $data['status'],
                $data['date']
            ]);
            
            $id = $pdo->lastInsertId();
            sendResponse(['success' => true, 'id' => $id, 'message' => 'Payment added successfully']);
        } catch (PDOException $e) {
            sendResponse(['error' => 'Failed to add payment: ' . $e->getMessage()], 500);
        }
        break;

    case 'PUT':
        try {
            $data = getRequestBody();
            
            // Validate payment method
            if (!in_array($data['method'], ['Bank Transfer', 'Credit Card'])) {
                sendResponse(['error' => 'Invalid payment method. Only Bank Transfer and Credit Card are allowed.'], 400);
                return;
            }
            
            $stmt = $pdo->prepare("
                UPDATE payments 
                SET booking_id = ?, amount = ?, method = ?, status = ?, date = ?
                WHERE id = ?
            ");
            
            $stmt->execute([
                $data['booking_id'],
                $data['amount'],
                $data['method'],
                $data['status'],
                $data['date'],
                $data['id']
            ]);
            
            sendResponse(['success' => true, 'message' => 'Payment updated successfully']);
        } catch (PDOException $e) {
            sendResponse(['error' => 'Failed to update payment: ' . $e->getMessage()], 500);
        }
        break;

    case 'DELETE':
        try {
            $data = getRequestBody();
            
            $stmt = $pdo->prepare("DELETE FROM payments WHERE id = ?");
            $stmt->execute([$data['id']]);
            
            sendResponse(['success' => true, 'message' => 'Payment deleted successfully']);
        } catch (PDOException $e) {
            sendResponse(['error' => 'Failed to delete payment: ' . $e->getMessage()], 500);
        }
        break;

    default:
        sendResponse(['error' => 'Method not allowed'], 405);
        break;
}
?>
