<?php
// Simple email configuration checker
header('Content-Type: application/json');

$email_config = [
    'mail_function_available' => function_exists('mail'),
    'sendmail_path' => ini_get('sendmail_path'),
    'smtp_configured' => !empty(ini_get('SMTP')),
    'smtp_host' => ini_get('SMTP'),
    'smtp_port' => ini_get('smtp_port'),
    'php_version' => phpversion(),
    'server_info' => $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown'
];

echo json_encode([
    'email_config' => $email_config,
    'recommendations' => [
        'For local testing (XAMPP): Configure sendmail or use a local SMTP server',
        'For production: Use a proper SMTP service like Gmail, SendGrid, or Mailgun',
        'Make sure your server can send emails (check with hosting provider)'
    ]
]);
?>
