<?php
require_once 'config.php';

// Try to use SMTP service first, fallback to simple service
if (file_exists(__DIR__ . '/phpmailer/src/PHPMailer.php')) {
    require_once 'smtp_email_service.php';
    $emailServiceClass = 'SMTPEmailService';
} else {
    require_once 'simple_email_service.php';
    $emailServiceClass = 'SimpleEmailService';
}

$pdo = getConnection();
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        try {
            $stmt = $pdo->query("SELECT * FROM bookings ORDER BY id DESC");
            $bookings = $stmt->fetchAll();
            sendResponse($bookings);
        } catch (PDOException $e) {
            sendResponse(['error' => 'Failed to fetch bookings: ' . $e->getMessage()], 500);
        }
        break;

    case 'POST':
        try {
            $data = getRequestBody();
            
            // Log the received data for debugging
            error_log("Booking POST request received: " . json_encode($data));
            
            // Validate required fields with detailed messages
            $required_fields = ['vehicle_id', 'passenger_id', 'rental_type_id', 'start_date', 'end_date', 'status', 'total_amount'];
            $missing_fields = [];
            $invalid_fields = [];
            
            foreach ($required_fields as $field) {
                if (!isset($data[$field])) {
                    $missing_fields[] = $field . ' (not provided)';
                } elseif ($data[$field] === '' || $data[$field] === null) {
                    $missing_fields[] = $field . ' (empty value)';
                } elseif ($field === 'total_amount' && !is_numeric($data[$field])) {
                    $invalid_fields[] = $field . ' (must be numeric)';
                }
            }
            
            if (!empty($missing_fields) || !empty($invalid_fields)) {
                $error_response = [
                    'error' => 'Validation failed',
                    'missing_fields' => $missing_fields,
                    'invalid_fields' => $invalid_fields,
                    'received_data' => $data,
                    'required_fields' => $required_fields
                ];
                error_log("Booking validation failed: " . json_encode($error_response));
                sendResponse($error_response, 400);
                return;
            }
            
            // Validate foreign key references
            $validation_errors = [];
            
            // Check if vehicle exists
            $vehicle_check = $pdo->prepare("SELECT id FROM vehicles WHERE id = ?");
            $vehicle_check->execute([$data['vehicle_id']]);
            if (!$vehicle_check->fetch()) {
                $validation_errors[] = "Vehicle ID {$data['vehicle_id']} does not exist";
            }
            
            // Check if passenger exists
            $passenger_check = $pdo->prepare("SELECT id, email FROM passengers WHERE id = ?");
            $passenger_check->execute([$data['passenger_id']]);
            $passenger = $passenger_check->fetch();
            if (!$passenger) {
                $validation_errors[] = "Passenger ID {$data['passenger_id']} does not exist";
            }
            
            // Check if rental type exists
            $rental_type_check = $pdo->prepare("SELECT id FROM rental_types WHERE id = ?");
            $rental_type_check->execute([$data['rental_type_id']]);
            if (!$rental_type_check->fetch()) {
                $validation_errors[] = "Rental Type ID {$data['rental_type_id']} does not exist";
            }
            
            if (!empty($validation_errors)) {
                $error_response = [
                    'error' => 'Foreign key validation failed',
                    'validation_errors' => $validation_errors,
                    'received_data' => $data
                ];
                error_log("Booking foreign key validation failed: " . json_encode($error_response));
                sendResponse($error_response, 400);
                return;
            }
            
            // If customer_email is not provided, get it from passenger
            if (empty($data['customer_email'])) {
                $data['customer_email'] = $passenger ? $passenger['email'] : '';
            }
            
            $stmt = $pdo->prepare("
                INSERT INTO bookings (vehicle_id, passenger_id, customer_email, rental_type_id, start_date, end_date, status, total_amount) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ");
            
            $stmt->execute([
                $data['vehicle_id'],
                $data['passenger_id'],
                $data['customer_email'],
                $data['rental_type_id'],
                $data['start_date'],
                $data['end_date'],
                $data['status'],
                $data['total_amount']
            ]);
            
            $id = $pdo->lastInsertId();

            // Send confirmation email
            if (!empty($data['customer_email'])) {
                try {
                    $emailService = new $emailServiceClass();
                    
                    // Get related data for email
                    $vehicle_stmt = $pdo->prepare("SELECT * FROM vehicles WHERE id = ?");
                    $vehicle_stmt->execute([$data['vehicle_id']]);
                    $vehicle = $vehicle_stmt->fetch();
                    
                    $passenger_stmt = $pdo->prepare("SELECT * FROM passengers WHERE id = ?");
                    $passenger_stmt->execute([$data['passenger_id']]);
                    $passenger = $passenger_stmt->fetch();
                    
                    $rental_type_stmt = $pdo->prepare("SELECT * FROM rental_types WHERE id = ?");
                    $rental_type_stmt->execute([$data['rental_type_id']]);
                    $rental_type = $rental_type_stmt->fetch();
                    
                    // Get the created booking
                    $booking_stmt = $pdo->prepare("SELECT * FROM bookings WHERE id = ?");
                    $booking_stmt->execute([$id]);
                    $booking = $booking_stmt->fetch();
                    
                    // Send email
                    $emailSent = $emailService->sendBookingConfirmation($booking, $vehicle, $passenger, $rental_type);
                    
                    sendResponse([
                        'success' => true, 
                        'id' => $id, 
                        'message' => 'Booking added successfully',
                        'email_sent' => $emailSent
                    ]);
                } catch (Exception $e) {
                    error_log("Failed to send booking confirmation email: " . $e->getMessage());
                    sendResponse([
                        'success' => true, 
                        'id' => $id, 
                        'message' => 'Booking added successfully (email failed)',
                        'email_error' => $e->getMessage()
                    ]);
                }
            } else {
                sendResponse(['success' => true, 'id' => $id, 'message' => 'Booking added successfully']);
            }
        } catch (PDOException $e) {
            sendResponse(['error' => 'Failed to add booking: ' . $e->getMessage()], 500);
        }
        break;

    case 'PUT':
        try {
            $data = getRequestBody();
            
            // Validate required fields
            $required_fields = ['id', 'vehicle_id', 'passenger_id', 'rental_type_id', 'start_date', 'end_date', 'status', 'total_amount'];
            foreach ($required_fields as $field) {
                if (!isset($data[$field]) || $data[$field] === '') {
                    sendResponse(['error' => "Missing required field: $field"], 400);
                    return;
                }
            }
            
            // If customer_email is not provided, get it from passenger
            if (empty($data['customer_email'])) {
                $passenger_stmt = $pdo->prepare("SELECT email FROM passengers WHERE id = ?");
                $passenger_stmt->execute([$data['passenger_id']]);
                $passenger = $passenger_stmt->fetch();
                $data['customer_email'] = $passenger ? $passenger['email'] : '';
            }
            
            $stmt = $pdo->prepare("
                UPDATE bookings 
                SET vehicle_id = ?, passenger_id = ?, customer_email = ?, rental_type_id = ?, start_date = ?, end_date = ?, status = ?, total_amount = ?
                WHERE id = ?
            ");
            
            $stmt->execute([
                $data['vehicle_id'],
                $data['passenger_id'],
                $data['customer_email'],
                $data['rental_type_id'],
                $data['start_date'],
                $data['end_date'],
                $data['status'],
                $data['total_amount'],
                $data['id']
            ]);
            
            sendResponse(['success' => true, 'message' => 'Booking updated successfully']);
        } catch (PDOException $e) {
            sendResponse(['error' => 'Failed to update booking: ' . $e->getMessage()], 500);
        }
        break;

    case 'DELETE':
        try {
            $data = getRequestBody();
            
            if (!isset($data['id'])) {
                sendResponse(['error' => 'Missing booking ID'], 400);
                return;
            }
            
            $stmt = $pdo->prepare("DELETE FROM bookings WHERE id = ?");
            $stmt->execute([$data['id']]);
            
            sendResponse(['success' => true, 'message' => 'Booking deleted successfully']);
        } catch (PDOException $e) {
            sendResponse(['error' => 'Failed to delete booking: ' . $e->getMessage()], 500);
        }
        break;

    default:
        sendResponse(['error' => 'Method not allowed'], 405);
        break;
}
?>
