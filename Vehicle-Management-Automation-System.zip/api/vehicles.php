<?php
require_once 'config.php';

$pdo = getConnection();
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        try {
            $stmt = $pdo->query("SELECT * FROM vehicles ORDER BY id DESC");
            $vehicles = $stmt->fetchAll();
            sendResponse($vehicles);
        } catch (PDOException $e) {
            sendResponse(['error' => 'Failed to fetch vehicles: ' . $e->getMessage()], 500);
        }
        break;

    case 'POST':
        try {
            $data = getRequestBody();
            
            $stmt = $pdo->prepare("
                INSERT INTO vehicles (make, model, year, license_plate, type, status) 
                VALUES (?, ?, ?, ?, ?, ?)
            ");
            
            $stmt->execute([
                $data['make'],
                $data['model'],
                $data['year'],
                $data['license_plate'],
                $data['type'],
                $data['status']
            ]);
            
            $id = $pdo->lastInsertId();
            sendResponse(['success' => true, 'id' => $id, 'message' => 'Vehicle added successfully']);
        } catch (PDOException $e) {
            sendResponse(['error' => 'Failed to add vehicle: ' . $e->getMessage()], 500);
        }
        break;

    case 'PUT':
        try {
            $data = getRequestBody();
            
            $stmt = $pdo->prepare("
                UPDATE vehicles 
                SET make = ?, model = ?, year = ?, license_plate = ?, type = ?, status = ?
                WHERE id = ?
            ");
            
            $stmt->execute([
                $data['make'],
                $data['model'],
                $data['year'],
                $data['license_plate'],
                $data['type'],
                $data['status'],
                $data['id']
            ]);
            
            sendResponse(['success' => true, 'message' => 'Vehicle updated successfully']);
        } catch (PDOException $e) {
            sendResponse(['error' => 'Failed to update vehicle: ' . $e->getMessage()], 500);
        }
        break;

    case 'DELETE':
        try {
            $data = getRequestBody();
            
            $stmt = $pdo->prepare("DELETE FROM vehicles WHERE id = ?");
            $stmt->execute([$data['id']]);
            
            sendResponse(['success' => true, 'message' => 'Vehicle deleted successfully']);
        } catch (PDOException $e) {
            sendResponse(['error' => 'Failed to delete vehicle: ' . $e->getMessage()], 500);
        }
        break;

    default:
        sendResponse(['error' => 'Method not allowed'], 405);
        break;
}
?>
