<?php
require_once 'config.php';

$pdo = getConnection();
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        try {
            $stmt = $pdo->query("SELECT * FROM rental_types ORDER BY id DESC");
            $rentalTypes = $stmt->fetchAll();
            sendResponse($rentalTypes);
        } catch (PDOException $e) {
            sendResponse(['error' => 'Failed to fetch rental types: ' . $e->getMessage()], 500);
        }
        break;

    case 'POST':
        try {
            $data = getRequestBody();
            
            $stmt = $pdo->prepare("
                INSERT INTO rental_types (name, description, base_rate, duration) 
                VALUES (?, ?, ?, ?)
            ");
            
            $stmt->execute([
                $data['name'],
                $data['description'],
                $data['base_rate'],
                $data['duration']
            ]);
            
            $id = $pdo->lastInsertId();
            sendResponse(['success' =>  true, 'id' => $id, 'message' => 'Rental type added successfully']);
        } catch (PDOException $e) {
            sendResponse(['error' => 'Failed to add rental type: ' . $e->getMessage()], 500);
        }
        break;

    case 'PUT':
        try {
            $data = getRequestBody();
            
            $stmt = $pdo->prepare("
                UPDATE rental_types 
                SET name = ?, description = ?, base_rate = ?, duration = ?
                WHERE id = ?
            ");
            
            $stmt->execute([
                $data['name'],
                $data['description'],
                $data['base_rate'],
                $data['duration'],
                $data['id']
            ]);
            
            sendResponse(['success' => true, 'message' => 'Rental type updated successfully']);
        } catch (PDOException $e) {
            sendResponse(['error' => 'Failed to update rental type: ' . $e->getMessage()], 500);
        }
        break;

    case 'DELETE':
        try {
            $data = getRequestBody();
            
            $stmt = $pdo->prepare("DELETE FROM rental_types WHERE id = ?");
            $stmt->execute([$data['id']]);
            
            sendResponse(['success' => true, 'message' => 'Rental type deleted successfully']);
        } catch (PDOException $e) {
            sendResponse(['error' => 'Failed to delete rental type: ' . $e->getMessage()], 500);
        }
        break;

    default:
        sendResponse(['error' => 'Method not allowed'], 405);
        break;
}
?>
