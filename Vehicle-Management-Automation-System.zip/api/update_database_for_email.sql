-- Add email tracking to bookings table
ALTER TABLE bookings 
ADD COLUMN customer_email VARCHAR(100) AFTER passenger_id,
ADD INDEX idx_customer_email (customer_email);

-- Update payments table to include credit card fields
ALTER TABLE payments 
ADD COLUMN card_type ENUM('visa', 'mastercard') AFTER method,
ADD COLUMN card_last4 VARCHAR(4) AFTER card_type,
ADD COLUMN transaction_id VARCHAR(255) AFTER card_last4,
ADD INDEX idx_transaction_id (transaction_id),
ADD INDEX idx_booking_payment (booking_id, status);

-- Update the method enum to only allow the two specified methods
ALTER TABLE payments 
MODIFY COLUMN method ENUM('Bank Transfer', 'Credit Card') NOT NULL;

-- Create email logs table to track sent emails
CREATE TABLE IF NOT EXISTS email_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    to_email VARCHAR(100) NOT NULL,
    subject VARCHAR(255) NOT NULL,
    status ENUM('sent', 'failed') NOT NULL,
    sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_to_email (to_email),
    INDEX idx_sent_at (sent_at)
);

