-- Safe database update script that checks for existing columns
USE vehicle_management;

-- Add customer_email to bookings table (only if it doesn't exist)
SET @sql = (SELECT IF(
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS 
     WHERE table_name = 'bookings' 
     AND column_name = 'customer_email' 
     AND table_schema = DATABASE()) > 0,
    'SELECT "customer_email column already exists"',
    'ALTER TABLE bookings ADD COLUMN customer_email VARCHAR(100) AFTER passenger_id'
));
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add index for customer_email (only if it doesn't exist)
SET @sql = (SELECT IF(
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.STATISTICS 
     WHERE table_name = 'bookings' 
     AND index_name = 'idx_customer_email' 
     AND table_schema = DATABASE()) > 0,
    'SELECT "idx_customer_email index already exists"',
    'ALTER TABLE bookings ADD INDEX idx_customer_email (customer_email)'
));
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add card_type to payments table (only if it doesn't exist)
SET @sql = (SELECT IF(
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS 
     WHERE table_name = 'payments' 
     AND column_name = 'card_type' 
     AND table_schema = DATABASE()) > 0,
    'SELECT "card_type column already exists"',
    'ALTER TABLE payments ADD COLUMN card_type ENUM(\'visa\', \'mastercard\') AFTER method'
));
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add card_last4 to payments table (only if it doesn't exist)
SET @sql = (SELECT IF(
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS 
     WHERE table_name = 'payments' 
     AND column_name = 'card_last4' 
     AND table_schema = DATABASE()) > 0,
    'SELECT "card_last4 column already exists"',
    'ALTER TABLE payments ADD COLUMN card_last4 VARCHAR(4) AFTER card_type'
));
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add transaction_id to payments table (only if it doesn't exist)
SET @sql = (SELECT IF(
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS 
     WHERE table_name = 'payments' 
     AND column_name = 'transaction_id' 
     AND table_schema = DATABASE()) > 0,
    'SELECT "transaction_id column already exists"',
    'ALTER TABLE payments ADD COLUMN transaction_id VARCHAR(255) AFTER card_last4'
));
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add indexes for payments table (only if they don't exist)
SET @sql = (SELECT IF(
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.STATISTICS 
     WHERE table_name = 'payments' 
     AND index_name = 'idx_transaction_id' 
     AND table_schema = DATABASE()) > 0,
    'SELECT "idx_transaction_id index already exists"',
    'ALTER TABLE payments ADD INDEX idx_transaction_id (transaction_id)'
));
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql = (SELECT IF(
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.STATISTICS 
     WHERE table_name = 'payments' 
     AND index_name = 'idx_booking_payment' 
     AND table_schema = DATABASE()) > 0,
    'SELECT "idx_booking_payment index already exists"',
    'ALTER TABLE payments ADD INDEX idx_booking_payment (booking_id, status)'
));
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Create email_logs table (only if it doesn't exist)
CREATE TABLE IF NOT EXISTS email_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    to_email VARCHAR(100) NOT NULL,
    subject VARCHAR(255) NOT NULL,
    status ENUM('sent', 'failed') NOT NULL,
    sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_to_email (to_email),
    INDEX idx_sent_at (sent_at)
);

-- Update existing bookings with passenger emails (only where customer_email is NULL)
UPDATE bookings b 
JOIN passengers p ON b.passenger_id = p.id 
SET b.customer_email = p.email 
WHERE b.customer_email IS NULL OR b.customer_email = '';

-- Show final table structure
SHOW COLUMNS FROM bookings;
SHOW COLUMNS FROM payments;
SHOW COLUMNS FROM email_logs;
