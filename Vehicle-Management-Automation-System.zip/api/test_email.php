<?php
require_once 'config.php';

// Try to use SMTP service first, fallback to simple service
if (file_exists(__DIR__ . '/phpmailer/src/PHPMailer.php')) {
    require_once 'smtp_email_service.php';
    $emailServiceClass = 'SMTPEmailService';
} else {
    require_once 'simple_email_service.php';
    $emailServiceClass = 'SimpleEmailService';
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendResponse(['error' => 'Method not allowed'], 405);
}

try {
    $data = getRequestBody();
    
    if (empty($data['email'])) {
        sendResponse(['error' => 'Email address is required'], 400);
    }
    
    $emailService = new $emailServiceClass();
    
    // Create test data
    $test_booking = [
        'id' => 'TEST001',
        'customer_email' => $data['email'],
        'start_date' => date('Y-m-d'),
        'end_date' => date('Y-m-d', strtotime('+1 day')),
        'status' => 'Active',
        'total_amount' => 50.00,
        'created_at' => date('Y-m-d H:i:s')
    ];
    
    $test_vehicle = [
        'year' => 2023,
        'make' => 'Toyota',
        'model' => 'Camry',
        'license_plate' => 'TEST-123',
        'type' => 'Sedan'
    ];
    
    $test_passenger = [
        'first_name' => 'Test',
        'last_name' => 'User',
        'email' => $data['email'],
        'phone' => '+1-555-TEST',
        'license_number' => 'TEST123456'
    ];
    
    $test_rental_type = [
        'name' => 'Daily Rental',
        'duration' => '24 hours'
    ];
    
    $success = $emailService->sendBookingConfirmation(
        $test_booking, 
        $test_vehicle, 
        $test_passenger, 
        $test_rental_type
    );
    
    if ($success) {
        sendResponse([
            'success' => true, 
            'message' => 'Test email sent successfully using ' . $emailServiceClass,
            'service_used' => $emailServiceClass
        ]);
    } else {
        sendResponse([
            'success' => false, 
            'message' => 'Failed to send test email',
            'service_used' => $emailServiceClass
        ], 500);
    }
    
} catch (Exception $e) {
    sendResponse(['error' => 'Email test failed: ' . $e->getMessage()], 500);
}
?>
