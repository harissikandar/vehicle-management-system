<?php
// Download PHPMailer from: https://github.com/PHPMailer/PHPMailer
// Extract to: api/phpmailer/ folder

require_once 'phpmailer/src/Exception.php';
require_once 'phpmailer/src/PHPMailer.php';
require_once 'phpmailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

class SMTPEmailService {
    private $smtp_host = 'smtp.gmail.com';
    private $smtp_port = 587;
    private $smtp_username = 'aliharis336@gmail.com'; // Replace with your Gmail
    private $smtp_password = 'puvh myae dwcb enef'; // Replace with your App Password
    private $from_email = 'your-email@gmail.com';
    private $from_name = 'Vehicle Management System';
    
    public function __construct() {
        // Load configuration from file if it exists
        $config_file = __DIR__ . '/email_config.json';
        if (file_exists($config_file)) {
            $config = json_decode(file_get_contents($config_file), true);
            if ($config) {
                $this->smtp_username = $config['smtp_username'] ?? $this->smtp_username;
                $this->smtp_password = $config['smtp_password'] ?? $this->smtp_password;
                $this->from_email = $config['from_email'] ?? $this->from_email;
                $this->from_name = $config['from_name'] ?? $this->from_name;
            }
        }
    }
    
    public function sendBookingConfirmation($booking_data, $vehicle_data, $passenger_data, $rental_type_data) {
        if (empty($booking_data['customer_email'])) {
            return false;
        }
        
        $to_email = $booking_data['customer_email'];
        $subject = "Booking Confirmation - #{$booking_data['id']}";
        
        $html_body = $this->generateBookingEmailTemplate($booking_data, $vehicle_data, $passenger_data, $rental_type_data);
        
        return $this->sendEmail($to_email, $subject, $html_body);
    }
    
    public function sendPaymentConfirmation($payment_data, $booking_data, $vehicle_data, $passenger_data) {
        if (empty($booking_data['customer_email'])) {
            return false;
        }
        
        $to_email = $booking_data['customer_email'];
        $subject = "Payment Receipt - #{$payment_data['id']}";
        
        $html_body = $this->generatePaymentEmailTemplate($payment_data, $booking_data, $vehicle_data, $passenger_data);
        
        return $this->sendEmail($to_email, $subject, $html_body);
    }
    
    private function sendEmail($to_email, $subject, $html_body) {
        $mail = new PHPMailer(true);
        
        try {
            // Server settings
            $mail->isSMTP();
            $mail->Host = $this->smtp_host;
            $mail->SMTPAuth = true;
            $mail->Username = $this->smtp_username;
            $mail->Password = $this->smtp_password;
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = $this->smtp_port;
            
            // Recipients
            $mail->setFrom($this->from_email, $this->from_name);
            $mail->addAddress($to_email);
            $mail->addReplyTo($this->from_email, $this->from_name);
            
            // Content
            $mail->isHTML(true);
            $mail->Subject = $subject;
            $mail->Body = $html_body;
            
            // Send email
            $success = $mail->send();
            
            // Log email attempt
            $this->logEmail($to_email, $subject, $success);
            
            return $success;
            
        } catch (Exception $e) {
            error_log("Email sending failed: " . $mail->ErrorInfo);
            $this->logEmail($to_email, $subject, false);
            return false;
        }
    }
    
    private function generateBookingEmailTemplate($booking, $vehicle, $passenger, $rental_type) {
        $booking_date = isset($booking['created_at']) ? date('F j, Y', strtotime($booking['created_at'])) : date('F j, Y');
        $start_date = date('F j, Y', strtotime($booking['start_date']));
        $end_date = date('F j, Y', strtotime($booking['end_date']));
        
        return "
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset='UTF-8'>
            <title>Booking Confirmation</title>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 20px; background-color: #f4f4f4; }
                .container { max-width: 600px; margin: 0 auto; background-color: white; padding: 30px; border-radius: 10px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
                .header { text-align: center; border-bottom: 3px solid #2563eb; padding-bottom: 20px; margin-bottom: 30px; }
                .header h1 { color: #2563eb; margin: 0; font-size: 28px; }
                .info-section { background-color: #f8fafc; padding: 20px; border-radius: 8px; margin: 20px 0; }
                .info-row { display: flex; justify-content: space-between; margin-bottom: 10px; padding: 8px 0; border-bottom: 1px solid #e2e8f0; }
                .info-row:last-child { border-bottom: none; }
                .label { font-weight: bold; color: #374151; }
                .value { color: #1f2937; }
                .total-amount { background-color: #2563eb; color: white; padding: 15px; border-radius: 8px; text-align: center; font-size: 18px; font-weight: bold; margin: 20px 0; }
                .footer { text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px solid #e2e8f0; color: #666; font-size: 14px; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h1>Booking Confirmation</h1>
                    <p>Vehicle Management System</p>
                    <p>Confirmation #: <strong>{$booking['id']}</strong></p>
                </div>
                
                <p>Dear {$passenger['first_name']} {$passenger['last_name']},</p>
                <p>Thank you for your booking! Your vehicle reservation has been confirmed.</p>
                
                <div class='info-section'>
                    <h3 style='margin-top: 0; color: #2563eb;'>Vehicle Information</h3>
                    <div class='info-row'>
                        <span class='label'>Vehicle:</span>
                        <span class='value'>{$vehicle['year']} {$vehicle['make']} {$vehicle['model']}</span>
                    </div>
                    <div class='info-row'>
                        <span class='label'>License Plate:</span>
                        <span class='value'>{$vehicle['license_plate']}</span>
                    </div>
                </div>
                
                <div class='info-section'>
                    <h3 style='margin-top: 0; color: #2563eb;'>Rental Information</h3>
                    <div class='info-row'>
                        <span class='label'>Start Date:</span>
                        <span class='value'>{$start_date}</span>
                    </div>
                    <div class='info-row'>
                        <span class='label'>End Date:</span>
                        <span class='value'>{$end_date}</span>
                    </div>
                    <div class='info-row'>
                        <span class='label'>Rental Type:</span>
                        <span class='value'>{$rental_type['name']}</span>
                    </div>
                </div>
                
                <div class='total-amount'>
                    Total Amount: $" . number_format($booking['total_amount'], 2) . "
                </div>
                
                <div class='footer'>
                    <p>Thank you for choosing our Vehicle Management System!</p>
                    <p>For support, contact us at support@vehiclemanagement.com</p>
                </div>
            </div>
        </body>
        </html>";
    }
    
    private function generatePaymentEmailTemplate($payment, $booking, $vehicle, $passenger) {
        $payment_date = isset($payment['created_at']) ? date('F j, Y g:i A', strtotime($payment['created_at'])) : date('F j, Y g:i A');
        
        $html_body = "
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset='UTF-8'>
            <title>Payment Receipt</title>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 20px; background-color: #f4f4f4; }
                .container { max-width: 600px; margin: 0 auto; background-color: white; padding: 30px; border-radius: 10px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
                .header { text-align: center; border-bottom: 3px solid #10b981; padding-bottom: 20px; margin-bottom: 30px; }
                .header h1 { color: #10b981; margin: 0; font-size: 28px; }
                .info-section { background-color: #f0f9ff; padding: 20px; border-radius: 8px; margin: 20px 0; }
                .info-row { display: flex; justify-content: space-between; margin-bottom: 10px; padding: 8px 0; border-bottom: 1px solid #e2e8f0; }
                .info-row:last-child { border-bottom: none; }
                .label { font-weight: bold; color: #374151; }
                .value { color: #1f2937; }
                .payment-amount { background-color: #10b981; color: white; padding: 15px; border-radius: 8px; text-align: center; font-size: 20px; font-weight: bold; margin: 20px 0; }
                .footer { text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px solid #e2e8f0; color: #666; font-size: 14px; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h1>Payment Receipt</h1>
                    <p>Vehicle Management System</p>
                    <p>Receipt #: <strong>{$payment['id']}</strong></p>
                </div>
                
                <p>Dear {$passenger['first_name']} {$passenger['last_name']},</p>
                <p>Thank you for your payment! Your transaction has been processed successfully.</p>
                
                <div class='info-section'>
                    <h3 style='margin-top: 0; color: #10b981;'>Payment Details</h3>
                    <div class='info-row'>
                        <span class='label'>Payment ID:</span>
                        <span class='value'>#{$payment['id']}</span>
                    </div>
                    <div class='info-row'>
                        <span class='label'>Transaction Date:</span>
                        <span class='value'>{$payment_date}</span>
                    </div>
                    <div class='info-row'>
                        <span class='label'>Payment Method:</span>
                        <span class='value'>{$payment['method']}</span>
                    </div>";
                    
        if (isset($payment['card_type']) && isset($payment['card_last4'])) {
            $html_body .= "
                    <div class='info-row'>
                        <span class='label'>Card Type:</span>
                        <span class='value'>" . strtoupper($payment['card_type']) . "</span>
                    </div>
                    <div class='info-row'>
                        <span class='label'>Card Number:</span>
                        <span class='value'>**** **** **** {$payment['card_last4']}</span>
                    </div>";
        }
        
        $html_body .= "
                </div>
                
                <div class='payment-amount'>
                    Amount Paid: $" . number_format($payment['amount'], 2) . "
                </div>
                
                <div class='footer'>
                    <p>Thank you for your business!</p>
                    <p>For support, contact us at support@vehiclemanagement.com</p>
                </div>
            </div>
        </body>
        </html>";
        
        return $html_body;
    }
    
    private function logEmail($to_email, $subject, $success) {
        try {
            $pdo = getConnection();
            $stmt = $pdo->prepare("
                INSERT INTO email_logs (to_email, subject, status, sent_at) 
                VALUES (?, ?, ?, NOW())
            ");
            $stmt->execute([$to_email, $subject, $success ? 'sent' : 'failed']);
        } catch (Exception $e) {
            error_log("Failed to log email: " . $e->getMessage());
        }
    }
}
?>
