<?php
// Disable error display to prevent HTML in JSON responses
ini_set('display_errors', 0);
ini_set('log_errors', 1);

// Database configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root'); // Default XAMPP username
define('DB_PASS', ''); // Default XAMPP password (empty)
define('DB_NAME', 'vehicle_management');

// Create database connection
function getConnection() {
    try {
        $pdo = new PDO(
            "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8",
            DB_USER,
            DB_PASS,
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]
        );
        return $pdo;
    } catch (PDOException $e) {
        // Clean any output buffer to prevent HTML errors
        if (ob_get_level()) {
            ob_clean();
        }
        
        http_response_code(500);
        header('Content-Type: application/json');
        echo json_encode(['error' => 'Database connection failed: ' . $e->getMessage()]);
        exit;
    }
}

// Clean any output buffer and set JSON response headers
if (ob_get_level()) {
    ob_clean();
}

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Helper function to send JSON response
function sendResponse($data, $status = 200) {
    // Clean any output buffer to prevent HTML errors
    if (ob_get_level()) {
        ob_clean();
    }
    
    http_response_code($status);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

// Helper function to get request body
function getRequestBody() {
    $input = file_get_contents('php://input');
    $data = json_decode($input, true);
    
    if (json_last_error() !== JSON_ERROR_NONE) {
        sendResponse(['error' => 'Invalid JSON in request body'], 400);
    }
    
    return $data;
}

// Error handler to prevent HTML errors in JSON responses
function handleError($errno, $errstr, $errfile, $errline) {
    if (ob_get_level()) {
        ob_clean();
    }
    
    sendResponse([
        'error' => 'PHP Error: ' . $errstr,
        'file' => $errfile,
        'line' => $errline
    ], 500);
}

// Set custom error handler
set_error_handler('handleError');

// Exception handler
function handleException($exception) {
    if (ob_get_level()) {
        ob_clean();
    }
    
    sendResponse([
        'error' => 'Uncaught Exception: ' . $exception->getMessage(),
        'file' => $exception->getFile(),
        'line' => $exception->getLine()
    ], 500);
}

set_exception_handler('handleException');
?>
