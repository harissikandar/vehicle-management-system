<?php
require_once 'config.php';

$pdo = getConnection();
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        try {
            $stmt = $pdo->query("SELECT * FROM passengers ORDER BY id DESC");
            $passengers = $stmt->fetchAll();
            sendResponse($passengers);
        } catch (PDOException $e) {
            sendResponse(['error' => 'Failed to fetch passengers: ' . $e->getMessage()], 500);
        }
        break;

    case 'POST':
        try {
            $data = getRequestBody();
            
            $stmt = $pdo->prepare("
                INSERT INTO passengers (first_name, last_name, email, phone, license_number) 
                VALUES (?, ?, ?, ?, ?)
            ");
            
            $stmt->execute([
                $data['first_name'],
                $data['last_name'],
                $data['email'],
                $data['phone'],
                $data['license_number']
            ]);
            
            $id = $pdo->lastInsertId();
            sendResponse(['success' => true, 'id' => $id, 'message' => 'Passenger added successfully']);
        } catch (PDOException $e) {
            sendResponse(['error' => 'Failed to add passenger: ' . $e->getMessage()], 500);
        }
        break;

    case 'PUT':
        try {
            $data = getRequestBody();
            
            $stmt = $pdo->prepare("
                UPDATE passengers 
                SET first_name = ?, last_name = ?, email = ?, phone = ?, license_number = ?
                WHERE id = ?
            ");
            
            $stmt->execute([
                $data['first_name'],
                $data['last_name'],
                $data['email'],
                $data['phone'],
                $data['license_number'],
                $data['id']
            ]);
            
            sendResponse(['success' => true, 'message' => 'Passenger updated successfully']);
        } catch (PDOException $e) {
            sendResponse(['error' => 'Failed to update passenger: ' . $e->getMessage()], 500);
        }
        break;

    case 'DELETE':
        try {
            $data = getRequestBody();
            
            $stmt = $pdo->prepare("DELETE FROM passengers WHERE id = ?");
            $stmt->execute([$data['id']]);
            
            sendResponse(['success' => true, 'message' => 'Passenger deleted successfully']);
        } catch (PDOException $e) {
            sendResponse(['error' => 'Failed to delete passenger: ' . $e->getMessage()], 500);
        }
        break;

    default:
        sendResponse(['error' => 'Method not allowed'], 405);
        break;
}
?>
