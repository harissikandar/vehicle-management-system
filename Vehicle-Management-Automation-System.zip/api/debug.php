<?php
require_once 'config.php';

// Debug endpoint to check system status
try {
    $pdo = getConnection();
    
    // Check database connection
    $db_status = "Connected";
    
    // Check tables exist
    $tables = [];
    $stmt = $pdo->query("SHOW TABLES");
    while ($row = $stmt->fetch()) {
        $tables[] = $row[array_keys($row)[0]];
    }
    
    // Check table structures
    $table_structures = [];
    foreach (['vehicles', 'passengers', 'rental_types', 'bookings', 'payments'] as $table) {
        if (in_array($table, $tables)) {
            $stmt = $pdo->query("DESCRIBE $table");
            $table_structures[$table] = $stmt->fetchAll();
        }
    }
    
    // Check email configuration
    $email_config = [
        'mail_function_available' => function_exists('mail'),
        'sendmail_path' => ini_get('sendmail_path'),
        'smtp_configured' => !empty(ini_get('SMTP')),
        'smtp_host' => ini_get('SMTP'),
        'smtp_port' => ini_get('smtp_port'),
    ];
    
    sendResponse([
        'status' => 'OK',
        'database' => $db_status,
        'tables' => $tables,
        'table_structures' => $table_structures,
        'email_config' => $email_config,
        'php_version' => phpversion(),
        'server_info' => $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown'
    ]);
    
} catch (Exception $e) {
    sendResponse([
        'status' => 'ERROR',
        'error' => $e->getMessage(),
        'trace' => $e->getTraceAsString()
    ], 500);
}
?>
