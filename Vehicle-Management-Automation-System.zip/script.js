// Global variables
let activeTab = "vehicles"
let searchTerm = ""
let currentEditId = null
let currentEditType = null
let deleteId = null
let deleteType = null

// API Base URL
const API_BASE = "api/"

// Initialize the application
document.addEventListener("DOMContentLoaded", () => {
  // Initialize Lucide icons
  lucide.createIcons()

  // Setup event listeners
  setupEventListeners()

  // Load initial data
  loadData()
})

function setupEventListeners() {
  // Tab navigation
  const navButtons = document.querySelectorAll(".nav-button")
  navButtons.forEach((button) => {
    button.addEventListener("click", function () {
      const tabName = this.getAttribute("data-tab")
      switchTab(tabName)
    })
  })

  // Search functionality
  const searchInput = document.getElementById("searchInput")
  searchInput.addEventListener("input", function () {
    searchTerm = this.value.toLowerCase()
    renderContent()
  })

  // Form submission
  const recordForm = document.getElementById("recordForm")
  recordForm.addEventListener("submit", handleFormSubmit)

  // Modal click outside to close
  const modalOverlay = document.getElementById("modalOverlay")
  modalOverlay.addEventListener("click", (e) => {
    if (e.target === modalOverlay) {
      closeModal()
    }
  })

  const receiptModal = document.getElementById("receiptModal")
  receiptModal.addEventListener("click", (e) => {
    if (e.target === receiptModal) {
      closeReceiptModal()
    }
  })

  const deleteModal = document.getElementById("deleteModal")
  deleteModal.addEventListener("click", (e) => {
    if (e.target === deleteModal) {
      closeDeleteModal()
    }
  })
}

// API Functions
async function apiRequest(endpoint, method = "GET", data = null) {
  try {
    const options = {
      method: method,
      headers: {
        "Content-Type": "application/json",
      },
    }

    if (data) {
      options.body = JSON.stringify(data)
    }

    const response = await fetch(API_BASE + endpoint, options)
    const result = await response.json()

    if (!response.ok) {
      throw new Error(result.message || "API request failed")
    }

    return result
  } catch (error) {
    console.error("API Error:", error)
    alert("Error: " + error.message)
    return null
  }
}

async function loadData() {
  try {
    const [vehicles, rentalTypes, passengers, bookings, payments] = await Promise.all([
      apiRequest("vehicles.php"),
      apiRequest("rental_types.php"),
      apiRequest("passengers.php"),
      apiRequest("bookings.php"),
      apiRequest("payments.php"),
    ])

    // Store data globally
    window.data = {
      vehicles: vehicles || [],
      rentalTypes: rentalTypes || [],
      passengers: passengers || [],
      bookings: bookings || [],
      payments: payments || [],
    }

    renderContent()
  } catch (error) {
    console.error("Error loading data:", error)
    // Fallback to sample data for demo
    loadSampleData()
  }
}

function loadSampleData() {
  window.data = {
    vehicles: [
      {
        id: "1",
        make: "Toyota",
        model: "Camry",
        year: 2023,
        license_plate: "ABC-123",
        status: "Available",
        type: "Sedan",
      },
      {
        id: "2",
        make: "Ford",
        model: "Transit",
        year: 2022,
        license_plate: "XYZ-789",
        status: "Rented",
        type: "Van",
      },
    ],
    rentalTypes: [
      {
        id: "1",
        name: "Daily Rental",
        description: "Standard daily vehicle rental",
        base_rate: 50,
        duration: "24 hours",
      },
    ],
    passengers: [
      {
        id: "1",
        first_name: "John",
        last_name: "Smith",
        email: "john.smith@email.com",
        phone: "+1-555-0123",
        license_number: "DL123456789",
      },
    ],
    bookings: [
      {
        id: "1",
        vehicle_id: "1",
        passenger_id: "1",
        rental_type_id: "1",
        start_date: "2024-01-15",
        end_date: "2024-01-16",
        status: "Active",
        total_amount: 50,
      },
    ],
    payments: [
      {
        id: "1",
        booking_id: "1",
        amount: 50,
        method: "Credit Card",
        status: "Completed",
        date: "2024-01-15",
      },
    ],
  }
  renderContent()
}

function switchTab(tabName) {
  activeTab = tabName

  // Update navigation buttons
  const navButtons = document.querySelectorAll(".nav-button")
  navButtons.forEach((button) => {
    button.classList.remove("active")
    if (button.getAttribute("data-tab") === tabName) {
      button.classList.add("active")
    }
  })

  // Update tab content
  const tabContents = document.querySelectorAll(".tab-content")
  tabContents.forEach((content) => {
    content.classList.remove("active")
  })

  const activeContent = document.getElementById(`${tabName}-tab`)
  if (activeContent) {
    activeContent.classList.add("active")
  }

  renderContent()
}

function renderContent() {
  switch (activeTab) {
    case "vehicles":
      renderVehicles()
      break
    case "rental-types":
      renderRentalTypes()
      break
    case "passengers":
      renderPassengers()
      break
    case "bookings":
      renderBookings()
      break
    case "payments":
      renderPayments()
      break
  }
}

function getStatusBadgeClass(status) {
  const statusLower = status.toLowerCase()
  switch (statusLower) {
    case "available":
      return "badge-available"
    case "rented":
      return "badge-rented"
    case "maintenance":
      return "badge-maintenance"
    case "active":
      return "badge-active"
    case "completed":
      return "badge-completed"
    case "cancelled":
      return "badge-cancelled"
    case "pending":
      return "badge-pending"
    case "failed":
      return "badge-failed"
    default:
      return "badge-available"
  }
}

function filterData(dataArray, searchFields) {
  if (!searchTerm) return dataArray

  return dataArray.filter((item) => {
    return searchFields.some((field) => {
      const value = item[field]
      if (value === null || value === undefined) return false
      return value.toString().toLowerCase().includes(searchTerm)
    })
  })
}

// Render functions
function renderVehicles() {
  const grid = document.getElementById("vehicles-grid")
  const filteredVehicles = filterData(window.data.vehicles, ["make", "model", "license_plate", "type", "status"])

  grid.innerHTML = filteredVehicles
    .map(
      (vehicle) => `
        <div class="card">
            <div class="card-content">
                <div class="card-info">
                    <h3 class="card-title">${vehicle.year} ${vehicle.make} ${vehicle.model}</h3>
                    <p class="card-detail">License Plate: ${vehicle.license_plate}</p>
                    <p class="card-detail">Type: ${vehicle.type}</p>
                    <span class="badge ${getStatusBadgeClass(vehicle.status)}">${vehicle.status}</span>
                </div>
                <div class="card-actions">
                    <button class="action-button" onclick="openEditModal('vehicle', '${vehicle.id}')">
                        <i data-lucide="edit"></i>
                    </button>
                    <button class="action-button" onclick="openDeleteModal('vehicle', '${vehicle.id}')">
                        <i data-lucide="trash-2"></i>
                    </button>
                </div>
            </div>
        </div>
    `,
    )
    .join("")

  lucide.createIcons()
}

function renderRentalTypes() {
  const grid = document.getElementById("rental-types-grid")
  const filteredTypes = filterData(window.data.rentalTypes, ["name", "description", "duration"])

  grid.innerHTML = filteredTypes
    .map(
      (type) => `
        <div class="card">
            <div class="card-content">
                <div class="card-info">
                    <h3 class="card-title">${type.name}</h3>
                    <p class="card-detail">${type.description}</p>
                    <p class="card-detail">Base Rate: $${type.base_rate}</p>
                    <p class="card-detail">Duration: ${type.duration}</p>
                </div>
                <div class="card-actions">
                    <button class="action-button" onclick="openEditModal('rental-type', '${type.id}')">
                        <i data-lucide="edit"></i>
                    </button>
                    <button class="action-button" onclick="openDeleteModal('rental-type', '${type.id}')">
                        <i data-lucide="trash-2"></i>
                    </button>
                </div>
            </div>
        </div>
    `,
    )
    .join("")

  lucide.createIcons()
}

function renderPassengers() {
  const grid = document.getElementById("passengers-grid")
  const filteredPassengers = filterData(window.data.passengers, [
    "first_name",
    "last_name",
    "email",
    "phone",
    "license_number",
  ])

  grid.innerHTML = filteredPassengers
    .map(
      (passenger) => `
        <div class="card">
            <div class="card-content">
                <div class="card-info">
                    <h3 class="card-title">${passenger.first_name} ${passenger.last_name}</h3>
                    <p class="card-detail">Email: ${passenger.email}</p>
                    <p class="card-detail">Phone: ${passenger.phone}</p>
                    <p class="card-detail">License: ${passenger.license_number}</p>
                </div>
                <div class="card-actions">
                    <button class="action-button" onclick="openEditModal('passenger', '${passenger.id}')">
                        <i data-lucide="edit"></i>
                    </button>
                    <button class="action-button" onclick="openDeleteModal('passenger', '${passenger.id}')">
                        <i data-lucide="trash-2"></i>
                    </button>
                </div>
            </div>
        </div>
    `,
    )
    .join("")

  lucide.createIcons()
}

function renderBookings() {
  const grid = document.getElementById("bookings-grid")
  const filteredBookings = filterData(window.data.bookings, ["id", "vehicle_id", "passenger_id", "status"])

  grid.innerHTML = filteredBookings
    .map(
      (booking) => `
        <div class="card">
            <div class="card-content">
                <div class="card-info">
                    <h3 class="card-title">Booking #${booking.id}</h3>
                    <p class="card-detail">Vehicle ID: ${booking.vehicle_id}</p>
                    <p class="card-detail">Passenger ID: ${booking.passenger_id}</p>
                    <p class="card-detail">Period: ${booking.start_date} to ${booking.end_date}</p>
                    <p class="card-detail">Total Amount: $${booking.total_amount}</p>
                    <span class="badge ${getStatusBadgeClass(booking.status)}">${booking.status}</span>
                </div>
                <div class="card-actions">
                    <button class="action-button receipt-btn" onclick="viewReceipt('booking', '${booking.id}')">
                        <i data-lucide="receipt"></i>
                    </button>
                    <button class="action-button" onclick="openEditModal('booking', '${booking.id}')">
                        <i data-lucide="edit"></i>
                    </button>
                    <button class="action-button" onclick="openDeleteModal('booking', '${booking.id}')">
                        <i data-lucide="trash-2"></i>
                    </button>
                </div>
            </div>
        </div>
    `,
    )
    .join("")

  lucide.createIcons()
}

function renderPayments() {
  const grid = document.getElementById("payments-grid")
  const filteredPayments = filterData(window.data.payments, ["id", "booking_id", "method", "status"])

  grid.innerHTML = filteredPayments
    .map(
      (payment) => `
        <div class="card">
            <div class="card-content">
                <div class="card-info">
                    <h3 class="card-title">Payment #${payment.id}</h3>
                    <p class="card-detail">Booking ID: ${payment.booking_id}</p>
                    <p class="card-detail">Amount: $${payment.amount}</p>
                    <p class="card-detail">Method: ${payment.method}</p>
                    <p class="card-detail">Date: ${payment.date}</p>
                    <span class="badge ${getStatusBadgeClass(payment.status)}">${payment.status}</span>
                </div>
                <div class="card-actions">
                    <button class="action-button receipt-btn" onclick="viewReceipt('payment', '${payment.id}')">
                        <i data-lucide="receipt"></i>
                    </button>
                    <button class="action-button" onclick="openEditModal('payment', '${payment.id}')">
                        <i data-lucide="edit"></i>
                    </button>
                    <button class="action-button" onclick="openDeleteModal('payment', '${payment.id}')">
                        <i data-lucide="trash-2"></i>
                    </button>
                </div>
            </div>
        </div>
    `,
    )
    .join("")

  lucide.createIcons()
}

// Modal functions
function openAddModal(type) {
  currentEditId = null
  currentEditType = type
  document.getElementById("modalTitle").textContent = `Add ${getTypeLabel(type)}`
  generateForm(type)
  document.getElementById("modalOverlay").classList.add("active")
}

function openEditModal(type, id) {
  currentEditId = id
  currentEditType = type
  document.getElementById("modalTitle").textContent = `Edit ${getTypeLabel(type)}`
  generateForm(type, id)
  document.getElementById("modalOverlay").classList.add("active")
}

function closeModal() {
  document.getElementById("modalOverlay").classList.remove("active")
  currentEditId = null
  currentEditType = null
}

function openDeleteModal(type, id) {
  deleteType = type
  deleteId = id
  document.getElementById("deleteModal").classList.add("active")
}

function closeDeleteModal() {
  document.getElementById("deleteModal").classList.remove("active")
  deleteType = null
  deleteId = null
}

function getTypeLabel(type) {
  const labels = {
    vehicle: "Vehicle",
    "rental-type": "Rental Type",
    passenger: "Passenger",
    booking: "Booking",
    payment: "Payment",
  }
  return labels[type] || type
}

function generateForm(type, editId = null) {
  const formFields = document.getElementById("formFields")
  let html = ""
  let data = null

  if (editId) {
    const dataKey = type === "rental-type" ? "rentalTypes" : type + "s"
    data = window.data[dataKey].find((item) => item.id === editId)
  }

  switch (type) {
    case "vehicle":
      html = `
        <div class="form-group">
          <label class="form-label">Make</label>
          <input type="text" name="make" class="form-input" value="${data?.make || ""}" required>
        </div>
        <div class="form-group">
          <label class="form-label">Model</label>
          <input type="text" name="model" class="form-input" value="${data?.model || ""}" required>
        </div>
        <div class="form-group">
          <label class="form-label">Year</label>
          <input type="number" name="year" class="form-input" value="${data?.year || ""}" required>
        </div>
        <div class="form-group">
          <label class="form-label">License Plate</label>
          <input type="text" name="license_plate" class="form-input" value="${data?.license_plate || ""}" required>
        </div>
        <div class="form-group">
          <label class="form-label">Type</label>
          <input type="text" name="type" class="form-input" value="${data?.type || ""}" required>
        </div>
        <div class="form-group">
          <label class="form-label">Status</label>
          <select name="status" class="form-select" required>
            <option value="Available" ${data?.status === "Available" ? "selected" : ""}>Available</option>
            <option value="Rented" ${data?.status === "Rented" ? "selected" : ""}>Rented</option>
            <option value="Maintenance" ${data?.status === "Maintenance" ? "selected" : ""}>Maintenance</option>
          </select>
        </div>
      `
      break

    case "rental-type":
      html = `
        <div class="form-group">
          <label class="form-label">Name</label>
          <input type="text" name="name" class="form-input" value="${data?.name || ""}" required>
        </div>
        <div class="form-group">
          <label class="form-label">Description</label>
          <textarea name="description" class="form-textarea" required>${data?.description || ""}</textarea>
        </div>
        <div class="form-group">
          <label class="form-label">Base Rate ($)</label>
          <input type="number" name="base_rate" class="form-input" value="${data?.base_rate || ""}" step="0.01" required>
        </div>
        <div class="form-group">
          <label class="form-label">Duration</label>
          <input type="text" name="duration" class="form-input" value="${data?.duration || ""}" required>
        </div>
      `
      break

    case "passenger":
      html = `
        <div class="form-group">
          <label class="form-label">First Name</label>
          <input type="text" name="first_name" class="form-input" value="${data?.first_name || ""}" required>
        </div>
        <div class="form-group">
          <label class="form-label">Last Name</label>
          <input type="text" name="last_name" class="form-input" value="${data?.last_name || ""}" required>
        </div>
        <div class="form-group">
          <label class="form-label">Email</label>
          <input type="email" name="email" class="form-input" value="${data?.email || ""}" required>
        </div>
        <div class="form-group">
          <label class="form-label">Phone</label>
          <input type="tel" name="phone" class="form-input" value="${data?.phone || ""}" required>
        </div>
        <div class="form-group">
          <label class="form-label">License Number</label>
          <input type="text" name="license_number" class="form-input" value="${data?.license_number || ""}" required>
        </div>
      `
      break

    case "booking":
      const vehicleOptions = window.data.vehicles
        .map(
          (v) =>
            `<option value="${v.id}" ${data?.vehicle_id === v.id ? "selected" : ""}>${v.year} ${v.make} ${
              v.model
            }</option>`,
        )
        .join("")
      const passengerOptions = window.data.passengers
        .map(
          (p) =>
            `<option value="${p.id}" ${data?.passenger_id === p.id ? "selected" : ""}>${p.first_name} ${
              p.last_name
            }</option>`,
        )
        .join("")
      const rentalTypeOptions = window.data.rentalTypes
        .map((r) => `<option value="${r.id}" ${data?.rental_type_id === r.id ? "selected" : ""}>${r.name}</option>`)
        .join("")

      html = `
        <div class="form-group">
          <label class="form-label">Vehicle</label>
          <select name="vehicle_id" class="form-select" required>
            <option value="">Select Vehicle</option>
            ${vehicleOptions}
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Passenger</label>
          <select name="passenger_id" class="form-select" required>
            <option value="">Select Passenger</option>
            ${passengerOptions}
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Rental Type</label>
          <select name="rental_type_id" class="form-select" required>
            <option value="">Select Rental Type</option>
            ${rentalTypeOptions}
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Start Date</label>
          <input type="date" name="start_date" class="form-input" value="${data?.start_date || ""}" required>
        </div>
        <div class="form-group">
          <label class="form-label">End Date</label>
          <input type="date" name="end_date" class="form-input" value="${data?.end_date || ""}" required>
        </div>
        <div class="form-group">
          <label class="form-label">Total Amount ($)</label>
          <input type="number" name="total_amount" class="form-input" value="${data?.total_amount || ""}" step="0.01" required>
        </div>
        <div class="form-group">
          <label class="form-label">Status</label>
          <select name="status" class="form-select" required>
            <option value="Active" ${data?.status === "Active" ? "selected" : ""}>Active</option>
            <option value="Completed" ${data?.status === "Completed" ? "selected" : ""}>Completed</option>
            <option value="Cancelled" ${data?.status === "Cancelled" ? "selected" : ""}>Cancelled</option>
          </select>
        </div>
      `
      break

    case "payment":
      const bookingOptions = window.data.bookings
        .map((b) => `<option value="${b.id}" ${data?.booking_id === b.id ? "selected" : ""}>Booking #${b.id}</option>`)
        .join("")

      html = `
        <div class="form-group">
          <label class="form-label">Booking</label>
          <select name="booking_id" class="form-select" required>
            <option value="">Select Booking</option>
            ${bookingOptions}
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Amount ($)</label>
          <input type="number" name="amount" class="form-input" value="${data?.amount || ""}" step="0.01" required>
        </div>
        <div class="form-group">
          <label class="form-label">Payment Method</label>
          <select name="method" class="form-select" required>
            <option value="">Select Method</option>
            <option value="Bank Transfer" ${data?.method === "Bank Transfer" ? "selected" : ""}>Bank Transfer</option>
            <option value="Credit Card" ${data?.method === "Credit Card" ? "selected" : ""}>Credit Card</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Status</label>
          <select name="status" class="form-select" required>
            <option value="Pending" ${data?.status === "Pending" ? "selected" : ""}>Pending</option>
            <option value="Completed" ${data?.status === "Completed" ? "selected" : ""}>Completed</option>
            <option value="Failed" ${data?.status === "Failed" ? "selected" : ""}>Failed</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Date</label>
          <input type="date" name="date" class="form-input" value="${data?.date || ""}" required>
        </div>
      `
      break
  }

  formFields.innerHTML = html
}

async function handleFormSubmit(e) {
  e.preventDefault()

  const formData = new FormData(e.target)
  const data = Object.fromEntries(formData.entries())

  try {
    let endpoint = ""
    const method = currentEditId ? "PUT" : "POST"

    switch (currentEditType) {
      case "vehicle":
        endpoint = "vehicles.php"
        break
      case "rental-type":
        endpoint = "rental_types.php"
        break
      case "passenger":
        endpoint = "passengers.php"
        break
      case "booking":
        endpoint = "bookings.php"
        break
      case "payment":
        endpoint = "payments.php"
        break
    }

    if (currentEditId) {
      data.id = currentEditId
    }

    const result = await apiRequest(endpoint, method, data)

    if (result) {
      closeModal()
      loadData() // Reload data
      alert(currentEditId ? "Record updated successfully!" : "Record added successfully!")
    }
  } catch (error) {
    console.error("Error saving record:", error)
    alert("Error saving record: " + error.message)
  }
}

async function confirmDelete() {
  try {
    let endpoint = ""

    switch (deleteType) {
      case "vehicle":
        endpoint = "vehicles.php"
        break
      case "rental-type":
        endpoint = "rental_types.php"
        break
      case "passenger":
        endpoint = "passengers.php"
        break
      case "booking":
        endpoint = "bookings.php"
        break
      case "payment":
        endpoint = "payments.php"
        break
    }

    const result = await apiRequest(endpoint, "DELETE", { id: deleteId })

    if (result) {
      closeDeleteModal()
      loadData() // Reload data
      alert("Record deleted successfully!")
    }
  } catch (error) {
    console.error("Error deleting record:", error)
    alert("Error deleting record: " + error.message)
  }
}

// Receipt functions
function viewReceipt(type, id) {
  let receiptData = null

  if (type === "booking") {
    const booking = window.data.bookings.find((b) => b.id === id)
    const vehicle = window.data.vehicles.find((v) => v.id === booking.vehicle_id)
    const passenger = window.data.passengers.find((p) => p.id === booking.passenger_id)
    const rentalType = window.data.rentalTypes.find((r) => r.id === booking.rental_type_id)

    receiptData = {
      type: "Booking Receipt",
      id: booking.id,
      date: new Date().toLocaleDateString(),
      details: [
        { label: "Vehicle", value: `${vehicle?.year} ${vehicle?.make} ${vehicle?.model}` },
        { label: "License Plate", value: vehicle?.license_plate },
        { label: "Customer", value: `${passenger?.first_name} ${passenger?.last_name}` },
        { label: "Email", value: passenger?.email },
        { label: "Phone", value: passenger?.phone },
        { label: "Rental Type", value: rentalType?.name },
        { label: "Start Date", value: booking.start_date },
        { label: "End Date", value: booking.end_date },
        { label: "Status", value: booking.status },
      ],
      total: booking.total_amount,
    }
  } else if (type === "payment") {
    const payment = window.data.payments.find((p) => p.id === id)
    const booking = window.data.bookings.find((b) => b.id === payment.booking_id)

    receiptData = {
      type: "Payment Receipt",
      id: payment.id,
      date: payment.date,
      details: [
        { label: "Booking ID", value: payment.booking_id },
        { label: "Payment Method", value: payment.method },
        { label: "Status", value: payment.status },
        { label: "Transaction Date", value: payment.date },
      ],
      total: payment.amount,
    }
  }

  generateReceipt(receiptData)
  document.getElementById("receiptModal").classList.add("active")
}

function generateReceipt(data) {
  const receiptContent = document.getElementById("receiptContent")

  const html = `
    <div class="receipt">
      <div class="receipt-header">
        <h2 class="receipt-title">${data.type}</h2>
        <p class="receipt-subtitle">Vehicle Management System</p>
        <p class="receipt-subtitle">Receipt #${data.id} - ${data.date}</p>
      </div>
      
      <div class="receipt-section">
        <h3 class="receipt-section-title">Details</h3>
        ${data.details
          .map(
            (detail) => `
          <div class="receipt-row">
            <span>${detail.label}:</span>
            <span>${detail.value}</span>
          </div>
        `,
          )
          .join("")}
      </div>
      
      <div class="receipt-row total">
        <span>Total Amount:</span>
        <span>$${data.total}</span>
      </div>
      
      <div class="receipt-footer">
        <p>Thank you for your business!</p>
        <p>Generated on ${new Date().toLocaleString()}</p>
      </div>
    </div>
  `

  receiptContent.innerHTML = html
}

function closeReceiptModal() {
  document.getElementById("receiptModal").classList.remove("active")
}

function printReceipt() {
  const receiptContent = document.getElementById("receiptContent").innerHTML
  const printWindow = window.open("", "_blank")
  printWindow.document.write(`
    <html>
      <head>
        <title>Receipt</title>
        <style>
          body { font-family: Arial, sans-serif; margin: 20px; }
          .receipt { max-width: 600px; margin: 0 auto; }
          .receipt-header { text-align: center; margin-bottom: 30px; border-bottom: 2px solid #333; padding-bottom: 15px; }
          .receipt-title { font-size: 24px; font-weight: bold; margin-bottom: 10px; }
          .receipt-subtitle { color: #666; font-size: 14px; }
          .receipt-section { margin-bottom: 20px; }
          .receipt-section-title { font-weight: bold; margin-bottom: 10px; font-size: 18px; }
          .receipt-row { display: flex; justify-content: space-between; margin-bottom: 5px; padding: 5px 0; }
          .receipt-row.total { border-top: 1px solid #ccc; margin-top: 15px; padding-top: 10px; font-weight: bold; font-size: 18px; }
          .receipt-footer { text-align: center; margin-top: 30px; padding-top: 15px; border-top: 1px solid #ccc; color: #666; font-size: 14px; }
        </style>
      </head>
      <body>
        ${receiptContent}
      </body>
    </html>
  `)
  printWindow.document.close()
  printWindow.print()
}
